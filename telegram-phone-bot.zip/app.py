# AVISO IMPORTANTE
# Este bot usa uma API externa (NumVerify) para consultar dados públicos de um número de telefone.
# Não acessa dados sensíveis (como CPF ou RG), apenas informações autorizadas pela API.

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import requests
import os

API_TOKEN = os.getenv("BOT_TOKEN")  # Token do bot Telegram
NUMVERIFY_API_KEY = os.getenv("NUMVERIFY_API_KEY")  # Chave da API do NumVerify

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Envie um número de telefone com código do país (ex: +5511987654321). Use o comando /consulta +numero")

async def consultar_numero(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Por favor, envie o número com o sinal de +. Exemplo: /consulta +5511987654321")
        return

    numero = context.args[0]
    if not numero.startswith('+'):
        await update.message.reply_text("Formato inválido. O número deve começar com + seguido do DDD e telefone.")
        return

    url = f"http://apilayer.net/api/validate?access_key={NUMVERIFY_API_KEY}&number={numero}&country_code=BR&format=1"
    try:
        response = requests.get(url)
        data = response.json()

        if not data.get("valid"):
            await update.message.reply_text("Número inválido ou não encontrado.")
            return

        resposta = f"🔍 Resultado para {numero}:
"
        resposta += f"🌍 País: {data.get('country_name')}
"
        resposta += f"📍 Local: {data.get('location')}
"
        resposta += f"📱 Operadora: {data.get('carrier')}
"
        resposta += f"📞 Tipo de linha: {data.get('line_type')}"

        await update.message.reply_text(resposta)

    except Exception as e:
        await update.message.reply_text(f"Erro ao consultar: {str(e)}")

app = ApplicationBuilder().token(API_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("consulta", consultar_numero))
app.run_polling()
